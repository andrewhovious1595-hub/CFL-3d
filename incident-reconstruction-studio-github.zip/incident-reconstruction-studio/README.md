# Incident Reconstruction Studio

A responsive, static web application for building evidence-led incident scene exhibits.

## Features
- Upload a scene image, map, plan, or photograph as a background.
- Create multiple independently colored movement routes with numbered points.
- Place event, contact/interaction, reported-injury-area, reference/evidence, and area-of-interest markers.
- Build an event chronology and an evidence register.
- Export the scene as PNG, print the exhibit, download a project JSON file, and export a summary CSV.
- Reopen saved JSON projects in the app.
- Mobile-friendly layout; no server, database, build step, or API key required.

## Run locally
Open `index.html` in a modern browser. For a local development server, run:

```bash
python -m http.server 8000
```

Then visit `http://localhost:8000`.

## Deploy with GitHub Pages
1. Create a new GitHub repository, for example `incident-reconstruction-studio`.
2. Upload the contents of this package to the repository root (not the enclosing ZIP folder).
3. In the repository, open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select the `main` branch and `/ (root)`, then save.
6. Wait for the Pages deployment to finish. GitHub will show the public site URL in Settings → Pages.

A GitHub Actions workflow is also included at `.github/workflows/deploy.yml`. To use it, open **Settings → Pages**, set the source to **GitHub Actions**, and push to `main`.

## Data and privacy
This is a client-side static application. Project data and uploaded scene images are held in the current browser page memory until you export a project JSON file. The app does not upload evidence to a server. Treat exported project JSON files as sensitive case material and store/share them using your organization's approved secure process.

## Important limitations
This application is a visual exhibit builder, not forensic analysis software. It does not independently authenticate evidence, determine what happened, calculate speed or collision dynamics, establish causation, or produce expert opinions. Route geometry, marker positions, labels, and chronology are user-entered visualizations. Distinguish documented facts, expert interpretations, assumptions, and unresolved or disputed information. Have technical conclusions reviewed by appropriately qualified professionals. Injury-area markers are illustrative only and are not medical findings.

## Project structure

```text
incident-reconstruction-studio/
├── index.html
├── README.md
├── LICENSE
├── .nojekyll
└── .github/
    └── workflows/
        └── deploy.yml
```
